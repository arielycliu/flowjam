Fantasy Ren'py GUI template

This work is licensed under a Creative Commons Attribution 4.0 International License.

You may:
	-use this template for personal and commercial projects as long as proper attribution is given to the creator 'Skolaztika'.
	-edit parts of the template to fit your project.


This template contains additional music and fonts. If you use them please follow their licensing requirements.

------------------------------------------------------------------------------------------------------------------
SOME INSTRUCTIONS
------------------------------------------------------------------------------------------------------------------

• Use alternative main menu screen
	Navigate to the gui folder (game/gui). Rename the file 'main_menu' to something else, so if any complications arise you'll still have the file. Rename the file 'main_menu_alt' to 'main_menu'.

•Customize the gallery buttons
	In the gui/button folder you'll find two blank buttons you can customize. It is very important you save your custom buttons with the same name as the existing buttons (ex.: gallerybutton1_hover, gallerybutton1_idle etc.)
-------------------------------------------------------------------------------------------------------------------

If you have any questions you may contact me on any of these platforms:
	Email:skolaztika@outlook.hu

	Itch.io: https://skolaztika.itch.io/
	DeviantArt: https://www.deviantart.com/
	Tumblr: https://skolaztika.tumblr.com/